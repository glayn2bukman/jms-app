#!/bin/bash
JMSrecovery_PATH="/opt/jms-recovery"

# main server...
cd "$JMSrecovery_PATH"

if [ -f $JMSrecovery_PATH/server.pid ] 
    then 
        kill -9 `cat $JMSrecovery_PATH/server.pid`
fi

python server.py &

python send_mail_deamon.py &