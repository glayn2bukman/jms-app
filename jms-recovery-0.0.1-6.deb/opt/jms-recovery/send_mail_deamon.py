#this script is to be run as a deamon at startup!
import os, time, sys
import send_mail

path = os.path.dirname(__file__)

sleep_time = 60*60
target_time = 16 # 16hrs UTM -> 19hrs EAT

error_emails = ["mwengeza@gmail.com", "glayn2bukman@gmail.com"]

while 1:
    t = time.localtime()
    
    if t[3]==target_time:
        os.system("python \"{}\" 2> \"{}\"".format(
           os.path.join(path, "generate_excel.py"), 
           # read the log file below to check for errors in the deamon...                                                     
           os.path.join(path, "send_mail_deamon.log")
                ))
            
    time.sleep(sleep_time)        
