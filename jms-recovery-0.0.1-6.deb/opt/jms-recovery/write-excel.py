import xlsxwriter, os

# Create a workbook and add a worksheet.
if os.path.isdir("/storage/emulated/0"):
    # on android, there is no /tmp dir for XlsxWriter to store temporary files, so store em in_memory
    workbook = xlsxwriter.Workbook('test.xlsx', {'tmpdir': "/storage/emulated/0"})
else:
    workbook = xlsxwriter.Workbook('Expenses02.xlsx')

workbook.set_properties({
    'title': 'JMS Report',
    'subject': 'With document properties',
    'author': 'JMS Report Agent',
    'manager': 'JERM Technology',
    'company': 'Join MEdical Stores',
})

worksheet = workbook.add_worksheet()

# Add a bold format to use to highlight cells.
bold = workbook.add_format({'bold': True})
# Add a number format for cells with money.
money = workbook.add_format({'num_format': '###,###,###,###', 
                            "align":"left" # you want to align your figures to the left
                       })

# Write some data headers.
worksheet.write('A1', 'Item', bold)
worksheet.write('B1', 'Cost', bold)

# Some data we want to write to the worksheet.
expenses = (
    ['Rent', 15000],
    ['Gas', 10000],
    ['Food', 35000],
    ['Gym',52000],
)

# adjust the "Cost" column to accomodate the largets figure
worksheet.set_column(1,1, len(str(max([i[1] for i in expenses])))+3) # +3 will cater for the maximum possibl number of commas in the figure
        #set_column(first_column, last_column, width) -> set the width of all cols from <first_column> to <last_column> to <width>

# Start from the first cell below the headers.
row = 1
col = 0

# Iterate over the data and write it out row by row.
for item, cost in (expenses):
    worksheet.write(row, col, item)
    worksheet.write(row, col + 1, cost, money)
    row += 1

# Write a total using a formula.
worksheet.write(row, 0, 'Total',bold)
worksheet.write(row, 1, sum([i[1] for i in expenses]), money)

# add a url
worksheet.write_url(row+1, 0, "http://localhost", None, "my link") # same as worksheet.write("http://localhost")
worksheet.write(row+2, 0, "http://localhost", None, "second link")

# insert an image, scaled down(makes it smaller that is was)
worksheet.insert_image(0, 5, "../Android/data/JMS.jpg", {"x_scale":.5, "y_scale":.5})

# merge cells
merge_format = workbook.add_format({"align":"left", "bold":1, 'fg_color': '#D7E4BC'})
worksheet.merge_range(row+5,0, row+5, 3, "Merged 4 columns", merge_format)
        #merge_range(row0, col0, row1,col1, data, [formatting-options])


# insert charts
bargraph = workbook.add_chart({"type":"column",})

bargraph.add_series({
        "values":["Sheet1",1,1,4,1], 
        "categories":["Sheet1",1,0,4,0],
        "data_labels":{"value":1},
    
    })
bargraph.set_size({"x_scale":.8, "y_scale":1})

bargraph.set_x_axis({
    'name': "Fields of Sales",
    'name_font': {'size': 9, 'bold': True},
    'num_font': {'italic': True },
})

bargraph.set_y_axis({
    'name': 'Amount (millions of UGX)',
    'major_gridlines': {
                            'visible': 0,
                       },
    "visible":0
})

bargraph.set_legend({"none":1})


worksheet.insert_chart(row+5, 4, bargraph)

# set sheet tab color
worksheet.set_tab_color('green')

# protect worksheet(s) from modification
worksheet.protect("J-E-R-M--P-R-O-T-E-C-T-I-O-N")

# set landscape to landscape when printing
worksheet.set_landscape()

# when prining, set header to center
worksheet.set_header("&C&14JMS Daily Field Report; {}") # the &C aligns the header to the center
worksheet.set_footer("&R&8Produced by JERM Technology (http://www.jermtechnology.com)")

# center the data when printing
#worksheet.center_horizontally()
#worksheet.center_vertically()

# hide the gridlines when printing and even in excel
worksheet.hide_gridlines(2) # 0=dont hide grids, 1=hide printed grids, 2=hide both printed and screen grids

# close workbook (save)
workbook.close()
