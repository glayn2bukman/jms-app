import os, xlsxwriter, datetime, send_mail

path = os.path.dirname(__file__)

if not os.path.isdir(os.path.join(path, "reports")):
    os.mkdir(os.path.join(path, "reports"))

reports_path = os.path.join(path, "reports")
logo_path = os.path.join(path, "data")

def generate_excel(fname, col_titles, data, field, hide_grid=1, mark_numeric_extremes=1):
    """
    fname: filename (without the .xlsx extension)    
    
    col_titles: [(col1_title, type), (col2_title, type), ...] eg ["Age", "Name"]
    
    data: [[row1], [row2], ...]
    
    filed: string indicating the field of reporting
    
    hide_grid: bool to display(or not) the excel grid markings
    
    mark_numeric_extremes: boo to mark minimum and maximum values for numeric columns
    """
    
    fname += ".xlsx"
    fname = os.path.join(reports_path, fname)
    
    # init workbook + worksheet
    wb = xlsxwriter.Workbook(fname)
    ws = wb.add_worksheet("Report")

    # init styling formats
    col_title_format = wb.add_format({'bold': True, "font_size":13, "fg_color":"#aaaaaa"})
    bold = wb.add_format({'bold': True})
    figure_format = wb.add_format({'num_format': '###,###,###,###', "align":"left"})
    date_format = wb.add_format({'num_format': 'd, mmmm, yyyy', "align":"left"})
    left_align = wb.add_format({"align":"left"})
    total_format = wb.add_format({"bold":1, "font_size":12, "align":"left", 'num_format': '###,###,###,###', "fg_color":"#009494"})
    numbering_format = wb.add_format({"align":"left", "fg_color":"#aaaaaa"})
    merge_format = wb.add_format({"align":"left", "font_size":12, "bold":1})
    min_cell_format = wb.add_format({"fg_color":"#AA4433", 'num_format': '###,###,###,###', "align":"left"})
    max_cell_format = wb.add_format({"fg_color":"#33AA44", 'num_format': '###,###,###,###', "align":"left"})

    row, col = 0, 0

    ws.insert_image(row, col, os.path.join(logo_path,"JMS.jpg"), {"x_scale":.5, "y_scale":.5})

    row += 6


    ws.merge_range(row,col, row, col+3, "JMS Field Report",merge_format)
    row += 1
    ws.merge_range(row,col, row, col+3, "Report Category : \"{}\"".format(field),merge_format)
    row += 1
    ws.merge_range(row,col, row, col+3, "Report Span : {} - {}".format(data[0][0], data[-1][0]).format(field),merge_format)
    
    # define data writting offset
    row += 2
    col = 1
    
    figure_cols = [] # will store figures (columns to use the "fig" format style)
    widths = [1]+[0]*len(col_titles) # store column widths
    
    for index, col_title in enumerate(col_titles):
        ws.write(row, col, col_title, col_title_format)
        
        if len(str(col_title))>widths[col]:
            widths[col] = len(str(col_title))

        col += 1
        


    row, col = row+1, 1
    row_number = 1
    data_start = row, col
    
    for data_row in data:
        # number the row
        ws.write(row,0, row_number, numbering_format)

        for value_index, value in enumerate(data_row):

            if type(value) in [type(0), type(0.0)]:
                if not value_index in figure_cols: 
                    figure_cols.append(value_index)
                v = value
                ws.write(row, col, value, figure_format)

            elif col==1:
                # first column is always the date!
                v = "12, December, 2017"
                ws.write_datetime(row, col, datetime.datetime.strptime(value, "%d/%m/%Y"), date_format)
            else:
                v = value
                ws.write(row, col, value,left_align)

            # convert any funny unicode strings/xters to proper unicode xter...
            v = unicode(v).encode("utf-8", "ignore")

            if len(str(v))>widths[col]: 
                widths[col] = len(str(v))

            col += 1

        # update row n col values
        col = 1
        row += 1
        row_number += 1

    row += 1
    for index in figure_cols:
        total = 0
        for _row in data: 
            try: total += int(_row[index])
            except: pass
        ws.write(row, index+1, total, total_format)
        
        if len(str(total))+3 > widths[index+1]:
            # 3 is added to len(str(total)) above coz a long figure will have atmost 3 commas then formatted into human readable form
            widths[index+1] = len(str(total))+4

    if mark_numeric_extremes:
        for index in figure_cols:
            col_values = [_row[index] for _row in data]
            largest, smallest = max(col_values), min(col_values)
            
            if col_values.count(largest)>1:
                j = 0
                for value in col_values:
                    if value==largest:
                        ws.write(data_start[0]+j, data_start[1]+index, largest, max_cell_format)
                    j += 1
            else:
                ws.write(data_start[0]+col_values.index(largest), data_start[1]+index, largest, max_cell_format)

            if col_values.count(smallest)>1:
                j = 0
                for value in col_values:
                    if value==smallest:
                        ws.write(data_start[0]+j, data_start[1]+index, smallest, min_cell_format)
                    j += 1
            else:
                ws.write(data_start[0]+col_values.index(smallest), data_start[1]+index, smallest, min_cell_format)


    for _col, width in enumerate(widths):
        ws.set_column(_col, _col, width+1)

    # hide gridlines in both ui and printed page
    if hide_grid:
        ws.hide_gridlines(2)
    
    ws.set_footer("&R&9Produced by JERM Technology (http://www.jermtechnology.com)")

    # set landscape to landscape when printing
    ws.set_landscape()

    ws.protect("-Jerm-")
    wb.close()

    return fname # returned filename(full path) of generated xlsx file   

def send_client_email(fname, col_titles, data, field, mail_subject, mail_to, mail_body):
    attachment = generate_excel(fname, col_titles, data, field)
    send_mail.send_mail(mail_subject, [str(attachment)], [mail_to], mail_body)
    
if __name__=="__main__":
    excel_data = (
        
        "sample", 
        
        ["Date", "Time", "Agent", "Client", "O.G", "O.R"], 
        
        (
            ("02/03/2017", "15:53:31", "Bukman", "Mulago Hospital", 356000, 5632000),
            ("01/10/2017", "17:31:01", "Sembatya", "Mulago RefferalHospital", 153000, 18650000),
            ("06/03/2017", "12:27:11", "Henry Kamya", "Mengo Clinic", 563800, 960500),
            ("11/03/2017", "06:16:13", "Mbabazi Sofia", "Banda health services", 150600, 12000000),
            ("12/03/2017", "10:22:26", "N. Jeromia", "Ibanda Health Center", 200000, 13500500),
            ("04/03/2017", "19:03:44", "Niko Jaggwe", "IHK", 192300, 18650000),
            ("07/03/2017", "03:11:01", "John Sempiija", "Entebbe Grade B", 850500, 860400),
            ("09/03/2017", "09:49:16", "Bwana Ash", "Nsamyba Hospital", 369000, 795000),
            ("10/03/2017", "11:38:34", "Murungi Allanz oss", "Kololo Dentist's Home", 197000, 916000),
            
        ),
        
        "Orders",
        
        )
    
    mail_data = ("My Test Email", "glayn2bukman@gmail.com", "Hey bruh!")
    
    data = excel_data + mail_data
    
    send_client_email(*data)
