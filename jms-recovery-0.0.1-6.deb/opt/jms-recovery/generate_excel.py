"""
This module reads data from  db/sales_reps_data.db and db/technical_reps_data.db every 20:00hrs.
It then converts the data into a suitable xlsx file and places it in the "reports" directory where its th emailed
to all emails listed in db/mail_recepients.db
"""

import os, xlsxwriter, datetime, time, send_mail, sqlite3 as sql

path = os.path.dirname(__file__)

if not os.path.isdir(os.path.join(path, "reports")):
    os.mkdir(os.path.join(path, "reports"))

reports_path = os.path.join(path, "reports")
logo_path = os.path.join(path, "data")
db_path = os.path.join(path, "db")

def get_data(date, area = "sales_reps"):
    try:
        if area=="sales_reps":
            with sql.connect(os.path.join(db_path, "sales_reps_data.db")) as conn:
                cur = conn.cursor()
                
                cur.execute("""select time,uname,client,order_generated,order_received,debt_collected,remark from data where 
                    date=?""", (date,))
                
                rep = cur.fetchall()
                
        elif area=="technical_reps":
            with sql.connect(os.path.join(db_path, "technical_reps_data.db")) as conn:
                cur = conn.cursor()
                
                cur.execute("""select time,uname,facility,CMEs,area_trained,remark from data where 
                    date=?""", (date,))
                
                rep = cur.fetchall()

        elif area=="technical_reps_tp":
            with sql.connect(os.path.join(db_path, "technical_reps_tp_data.db")) as conn:
                cur = conn.cursor()
                
                cur.execute("""select time,uname,facility,support_areas,remark from data where 
                    date=?""", (date,))
                
                rep = cur.fetchall()

        elif area=="technical_reps_core":
            with sql.connect(os.path.join(db_path, "technical_reps_core_data.db")) as conn:
                cur = conn.cursor()
                
                cur.execute("""select time,uname,facility,activities,personnels_engaged,time_spent,status_of_engagement,remark from data where 
                    date=?""", (date,))
                
                rep = cur.fetchall()

    except: 
        rep=[]

    return rep

def generate_excel(fname, col_titles, data, report_date, hide_grid=1, mark_numeric_extremes=1, field_section=""):
    
    # init workbook + worksheet
    wb = xlsxwriter.Workbook(fname, )
    ws = wb.add_worksheet("Report")

    # init styling formats
    col_title_format = wb.add_format({'bold': True, "font_size":13, "fg_color":"#aaaaaa"})
    bold = wb.add_format({'bold': True})
    figure_format = wb.add_format({'num_format': '###,###,###,###', "align":"left"})
    date_format = wb.add_format({'num_format': 'd, mmmm, yyyy', "align":"left"})
    left_align = wb.add_format({"align":"left"})
    total_format = wb.add_format({"bold":1, "font_size":12, "align":"left", 'num_format': '###,###,###,###', "fg_color":"#009494"})
    numbering_format = wb.add_format({"align":"left", "fg_color":"#aaaaaa"})

    merge_format = wb.add_format({"align":"left", "font_size":12, "bold":1})
    merge_format2 = wb.add_format({"align":"left", "bold":1})
    merge_format3 = wb.add_format({"align":"left", 'num_format': '###,###,###,###'})

    min_cell_format = wb.add_format({"fg_color":"#AA4433", 'num_format': '###,###,###,###', "align":"left"})
    max_cell_format = wb.add_format({"fg_color":"#33AA44", 'num_format': '###,###,###,###', "align":"left"})

    row, col = 0, 0

    ws.insert_image(row, col, os.path.join(logo_path,"JMS.jpg"), {"x_scale":.5, "y_scale":.5})

    row += 6

    ws.merge_range(row,col, row, col+5, "JMS Daily Field Report; {} ({})".format(field_section, report_date),merge_format)
    row += 1
    ws.merge_range(row,col, row, col+4, "Report Time Span : {} - {}".format(data[0][0], data[-1][0]),merge_format)
    
    if "Sales" in fname:
        row += 2
        col = 0
        ws.merge_range(row,col, row, col+6, "Sales Summary(all amounts in UGX)",merge_format)

        row += 1
        ws.merge_range(row, col, row, col+6, "(O.G=Order Generated, O.R=Order Received, D.C=Debt Collected)", merge_format3)

        row += 1
        col = 1
        ws.write(row+4, col, "Item", bold); ws.merge_range(row+4, col+1, row+4, col+2, "Total", merge_format2)

        row += 1        
        try:
            ws.write(row+4, col, "O.G"); ws.merge_range(row+4, col+1, row+4, col+2, sum([r[3] for r in data]), merge_format3)
        except: 
            # theres a fucking space "" in the data!
            # i gotta filter for this shit before the data should even be sent here!!!!
            for index, r in enumerate(data): 
                try: r[3]/1
                except: 
                    # be foreced to turn tuple into list...
                    data[index] = list(r)
                    data[index][3] = 0
            ws.write(row+4, col, "O.G"); ws.merge_range(row+4, col+1, row+4, col+2, sum([r[3] for r in data]), merge_format3)

        row += 1
        try:
            ws.write(row+4, col, "O.R"); ws.merge_range(row+4, col+1, row+4, col+2, sum([r[4] for r in data]), merge_format3)
        except: 
            # theres a fucking space "" in the data!
            # i gotta filter for this shit before the data should even be sent here!!!!
            for index, r in enumerate(data): 
                try: r[4]/1
                except: 
                    # be foreced to turn tuple into list...
                    data[index] = list(r)
                    data[index][4] = 0
            ws.write(row+4, col, "O.R"); ws.merge_range(row+4, col+1, row+4, col+2, sum([r[4] for r in data]), merge_format3)

        row += 1
        try:
            ws.write(row+4, col, "D.C"); ws.merge_range(row+4, col+1, row+4, col+2, sum([r[5] for r in data]), merge_format3)
        except: 
            # theres a fucking space "" in the data!
            # i gotta filter for this shit before the data should even be sent here!!!!
            for index, r in enumerate(data): 
                try: r[5]/1
                except: 
                    # be foreced to turn tuple into list...
                    data[index] = list(r)
                    data[index][5] = 0
            ws.write(row+4, col, "D.C"); ws.merge_range(row+4, col+1, row+4, col+2, sum([r[5] for r in data]), merge_format3)

        bargraph = wb.add_chart({"type":"column"})

        bargraph.add_series({
                "values":["Report",row-2+4,col+1,row+4,col+1], 
                "categories":["Report",row-2+4,col,row+4,col],
                "data_labels":{"value":1},
                'num_format': '###,###,###,###',
                "gradient":{"colors":["#aaaaaa", "#222222"]},
                "border":{"color":"#333333"},
            
            })
        bargraph.set_size({"x_scale":.8, "y_scale":.8})

        bargraph.set_x_axis({
            #'name': "Fields of Sales",
            'name_font': {'size': 9, 'bold': True},
            'num_font': {'italic': True },
        })

        bargraph.set_y_axis({
            #'name': 'Amount (UGX)',
            'major_gridlines': {
                                    'visible': 0,
                               },
            "visible":0
        })

        bargraph.set_legend({"none":1})
        #bargraph.set_plotarea({"gradient":{"colors":["#777777", "#cccccc"]}})
        #bargraph.set_chartarea({"gradient":{"colors":["#777777", "#cccccc"]}})


        ws.insert_chart(row-2, col+3, bargraph)

        row += 9


    row += 2
    col = 1
    
    figure_cols = [] # will store figures (columns to use the "fig" format style)
    widths = [1]+[0]*len(col_titles) # store column widths
    
    for index, col_title in enumerate(col_titles):
        ws.write(row, col, col_title, col_title_format)
        
        if len(str(col_title))>widths[col]:
            widths[col] = len(str(col_title))

        col += 1
        


    row, col = row+1, 1
    row_number = 1
    data_start = row, col
    
    for data_row in data:
        # number the row
        ws.write(row,0, row_number, numbering_format)

        for value_index, value in enumerate(data_row):

            if type(value) in [type(0), type(0.0)]:
                if not value_index in figure_cols: 
                    figure_cols.append(value_index)
                v = value
                ws.write(row, col, value, figure_format)

            else:
                v = value
                ws.write(row, col, value,left_align)

            # convert any funny xters to proper unicode... 
            v = unicode(v).encode("utf-8","ignore") 

            if len(str(v))>widths[col]: 
                widths[col] = len(str(v))

            col += 1

        # update row n col values
        col = 1
        row += 1
        row_number += 1

    row += 1
    for index in figure_cols:
        total = sum([_row[index] for _row in data])
        ws.write(row, index+1, total, total_format)
        
        if len(str(total))+3 > widths[index+1]:
            # 3 is added to len(str(total)) above coz a long figure will have atmost 3 commas then formatted into human readable form
            widths[index+1] = len(str(total))+4

    if mark_numeric_extremes:
        for index in figure_cols:
            col_values = [_row[index] for _row in data]
            largest, smallest = max(col_values), min(col_values)
            
            if col_values.count(largest)>1:
                j = 0
                for value in col_values:
                    if value==largest:
                        ws.write(data_start[0]+j, data_start[1]+index, largest, max_cell_format)
                    j += 1
            else:
                ws.write(data_start[0]+col_values.index(largest), data_start[1]+index, largest, max_cell_format)

            if col_values.count(smallest)>1:
                j = 0
                for value in col_values:
                    if value==smallest:
                        ws.write(data_start[0]+j, data_start[1]+index, smallest, min_cell_format)
                    j += 1
            else:
                ws.write(data_start[0]+col_values.index(smallest), data_start[1]+index, smallest, min_cell_format)


    for _col, width in enumerate(widths):
        ws.set_column(_col, _col, width+1)

    # hide gridlines in both ui and printed page
    if hide_grid:
        ws.hide_gridlines(2)
    
    ws.set_footer("&R&9Powered by JERM Technology (http://www.jermtechnology.com)")

    # set landscape to landscape when printing
    ws.set_landscape()

    ws.protect("-Jerm-")
    wb.close()
    

if __name__=="__main__":

    #fname, col_titles, data, report_date
    
    t = time.localtime()
    today = "{}{}{}".format("0"*(2-len(str(t[0])))+str(t[0]), "0"*(2-len(str(t[1])))+str(t[1]), "0"*(2-len(str(t[2])))+str(t[2]))
    
    sd = get_data(today)
    td = get_data(today, "technical_reps")
    td_tp = get_data(today, "technical_reps_tp")
    td_core = get_data(today, "technical_reps_core")
    
    sales_reps_attachment, technical_reps_attachment = "", ""    
    
    attachments = []
        
    if sd: 
        sales_reps_attachment = os.path.join(reports_path,"JMS Daily Report--Sales {}-{}-{}.xlsx".format(t[2],t[1],t[0]))
        generate_excel(sales_reps_attachment, 
            ["Time","Agent","Cient","O.G", "O.R", "D.C","Remark"], 
            sd, "{}/{}/{}".format(t[2],t[1],t[0]), field_section="Salesreps")

        attachments.append(sales_reps_attachment)

    if td: 
        technical_reps_attachment = os.path.join(reports_path,"JMS Daily Report--Technical {}-{}-{}.xlsx".format(t[2],t[1],t[0]))
        generate_excel(technical_reps_attachment, 
            ["Time","Agent","Facility","CMEs", "Topic", "Remark"], 
            td, "{}/{}/{}".format(t[2],t[1],t[0]), field_section="Technical Reps")

        attachments.append(technical_reps_attachment)

    if td_tp: 
        technical_reps_tp_attachment = os.path.join(reports_path,"JMS Daily Report--TRTP {}-{}-{}.xlsx".format(t[2],t[1],t[0]))
        generate_excel(technical_reps_tp_attachment, 
            ["Time","Agent","Facility","Support", "Remark"], 
            td_tp, "{}/{}/{}".format(t[2],t[1],t[0]), field_section="Technical Reps - TP")

        attachments.append(technical_reps_tp_attachment)

    if td_core: 
        technical_reps_core_attachment = os.path.join(reports_path,"JMS Daily Report--TRC {}-{}-{}.xlsx".format(t[2],t[1],t[0]))
        generate_excel(technical_reps_core_attachment,
            ["Time","Agent","Facility","Activities","Personnel Engaged","Duration","Status","Remark"], 
            td_core, "{}/{}/{}".format(t[2],t[1],t[0]), field_section="Technical Reps - Core")

        attachments.append(technical_reps_core_attachment)


    if (sd or td or td_tp or td_core):
        with sql.connect(os.path.join(path, "db", "mail_recepients.db")) as conn:
            cur = conn.cursor()
            cur.execute("select * from recepients")

            recepients = map(lambda lst: lst[0], cur.fetchall())

            # add jerm-staff emails to receive the daily reports
            recepients += ["mwengeza@gmail.com", "glayn2bukman@gmail.com", "njeromia@jermtechnology.com"]
        
        for recepient in recepients:
            send_mail.send_mail("JMS Daily Report - {}/{}/{}".format(t[2],t[1],t[0]), attachments, [recepient], "")
            
    print "send_mail deamon has been run at {}:{}, {}-{}-{}".format(t[3],t[4],t[2],t[1],t[0])
            
            
