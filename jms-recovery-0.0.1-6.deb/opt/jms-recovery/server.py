from flask import Flask, request, Response
import json, os
import sqlite3 as sql
import time

import send_client_email

import threading

app = Flask(__name__)
addr = ("0.0.0.0", 8123)

path = os.path.dirname(__file__)

with(open(os.path.join(path,'server.pid'),'wb')) as pidfile: pidfile.write(str(os.getpid()))


GOOGLE_MAPS_TEMPLATE = ["""
<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <title>JMS Report Maps</title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>
  </head>
  <body>
    <div id="map"></div>
    <script>

      function initMap() {""",
      
# ***************** SECTION OF INTEREST ***********************
      """
        var myLatLng = {lat: %s, lng: %s};
      """,
# ************************************************************

      """

        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 18,
          center: myLatLng
        });

        <!-- set map type to satellite
        map.setMapTypeId(google.maps.MapTypeId.HYBRID); 

        var marker = new google.maps.Marker({
          position: myLatLng,
          map: map,
          title: 'Hello World!'
        });

        // Add circle overlay and bind to marker
        var circle = new google.maps.Circle({
          map: map,
          radius: 50,    // metres
          fillColor: '#AA0000'
        });
        circle.bindTo('center', marker, 'position');
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDOMbfS5q6uxoThKf5cmeuF_tmbTyL40P8&callback=initMap">
    </script>
  </body>
</html>"""]

# create database files is non-existent

if not os.path.isdir(os.path.join(path, "db")):
    os.mkdir(os.path.join(path, "db"))
if not os.path.isdir(os.path.join(path, "reports")):
    os.mkdir(os.path.join(path, "reports"))

def init():
    """
    create db's if absent...
    """
    # users
    with sql.connect(os.path.join(path, "db", "users.db")) as conn:
        cur = conn.cursor()

        cur.execute("create table if not exists users (uname varchar(30), pswd varchar(30), account_type varchar(15))")
        conn.commit()

        cur.execute("select * from users")
        
        if not cur.fetchall():
            # add admin by default...
            cur.execute("insert into users values (?,?,?)", ("admin", "admin", "Admin"))

    # sales reps
    with sql.connect(os.path.join(path, "db", "sales_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("""create table if not exists data (
            uname varchar(30),
            date varchar(8),
            time varchar(8),
            client varchar(50),
            lat varchar(12),
            lon varchar(12),
            client_category varchar(15),
            client_old varchar(3),
            contact_people varchar(120),
            order_generated int,
            order_received int,
            debt_collected int,
            products_promoted varchar(500),
            remark varchar(300)
        )""")
        conn.commit()

        # NB: 
        #   contact_people is in format "names1:contact(s)1:email(s)1; names2:contact(s)2:email(s)2; ...."
        #   products_promoted is in format "item1:qtty1:amnt1; item2:qtty2:amnt2; ..."

    # technical reps
    with sql.connect(os.path.join(path, "db", "technical_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("""create table if not exists data (
            uname varchar(30),
            CMEs int,
            facility varchar(50),
            date varchar(8),
            time varchar(8),
            lat varchar(12),
            lon varchar(12),
            area_trained varchar(30),
            remark varchar(300)
        )""")
        conn.commit()

    # technical reps-3'rd party
    with sql.connect(os.path.join(path, "db", "technical_reps_tp_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("""create table if not exists data (
            uname varchar(30),
            facility varchar(50),
            date varchar(8),
            time varchar(8),
            lat varchar(12),
            lon varchar(12),
            support_areas varchar(200),
            incharge varchar(50),
            trainees varchar(300),
            remark varchar(300)
        )""")
        conn.commit()

    # technical reps-core
    with sql.connect(os.path.join(path, "db", "technical_reps_core_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("""create table if not exists data (
            uname varchar(30),
            facility varchar(50),
            date varchar(8),
            time varchar(8),
            lat varchar(12),
            lon varchar(12),
            activities varchar(200),
            personnels_engaged int,
            issues_arising varchar(300),
            time_spent varchar varchar(6),
            status_of_engagement varchar(50),
            perfomance_against_target varchar(200),
            remark varchar(300)
        )""")
        conn.commit()


    # promotional items
    with sql.connect(os.path.join(path, "db", "promotional_items.db")) as conn:
        cur = conn.cursor()

        cur.execute("""create table if not exists data (
            name varchar(30), 
            promotion_from varchar(8), 
            promotion_to varchar(8),
            unit_price int
        )""")
        conn.commit()

        # NB: promotion_from and promotion_to are in format "YYYYMMDD"

    # client categories
    with sql.connect(os.path.join(path, "db", "client_categories.db")) as conn:
        cur = conn.cursor()

        cur.execute("""create table if not exists categories ( name varchar(30) )""")
        conn.commit()

    # topics trained by the techinal rep
    with sql.connect(os.path.join(path, "db", "training_topics.db")) as conn:
        cur = conn.cursor()

        cur.execute("""create table if not exists topics ( name varchar(30) )""")
        conn.commit()

    # techinal rep-tp support areas
    with sql.connect(os.path.join(path, "db", "support_areas.db")) as conn:
        cur = conn.cursor()

        cur.execute("""create table if not exists support_areas ( name varchar(30) )""")
        conn.commit()
        
    # techinal rep-core activities
    with sql.connect(os.path.join(path, "db", "activities.db")) as conn:
        cur = conn.cursor()

        cur.execute("""create table if not exists activities ( name varchar(30) )""")
        conn.commit()

    # techinal rep-core statuses of engagement
    with sql.connect(os.path.join(path, "db", "statuses.db")) as conn:
        cur = conn.cursor()

        cur.execute("""create table if not exists statuses ( name varchar(30) )""")
        conn.commit()

    # recepients of daily reports
    with sql.connect(os.path.join(path, "db", "mail_recepients.db")) as conn:
        cur = conn.cursor()

        cur.execute("""create table if not exists recepients ( email varchar(50) )""")
        conn.commit()

init() # create any non-existing databases...

# define a function that wil allow responses to be sent to pages not served by this server
def reply_to_remote(reply):
    response = Response(reply)
    response.headers["Access-Control-Allow-Origin"] = "*" # allow all domains...
    return response

@app.route("/")
def root(): return "0"

@app.route("/users")
def get_users():
    """
    return a users in the system
    """
    with sql.connect(os.path.join(path, "db", "users.db")) as conn:
        cur = conn.cursor()

        cur.execute("select uname from users")
    
        res = cur.fetchall()
        users = [u[0] for u in res]

    reply = json.JSONEncoder().encode(sorted([k for k in users]))

    return reply_to_remote(reply)

@app.route("/pswd/<user>", methods=["POST", "GET"])
def get_pswd(user):
    """get user password"""
    with sql.connect(os.path.join(path, "db", "users.db")) as conn:
        cur = conn.cursor()
        cur.execute("select pswd from users where uname=?", (user,))
        res = cur.fetchone()
        reply = res[0]
    return reply_to_remote(reply)

@app.route("/user_in_system", methods=["POST"])
def user_in_system():
    target = request.form["target"]
    """
    tell if a user is in the system
    """
    with sql.connect(os.path.join(path, "db", "users.db")) as conn:
        cur = conn.cursor()

        cur.execute("select uname from users")
    
        res = cur.fetchall()
        users = [u[0] for u in res]

    reply = "1" if (target in users) else "0"

    return reply_to_remote(reply)


@app.route("/login", methods=["POST"])
def login():
    """ Return Codes:
    1: user not in system
    2: wrong password
    Admin: user is admin
    SalesRep: user is a sales rep
    Technical Rep: user is a technical rep 
    """
    
    uname = request.form["uname"]
    pswd = request.form["pswd"]

    found = 0

    with sql.connect(os.path.join(path, "db", "users.db")) as conn:
        cur = conn.cursor()

        cur.execute("select * from users where uname=?", (uname,))
    
        res = cur.fetchone()
        if res: found=1

    
    if not found: reply = "Error: User not in system!"
    
    elif pswd!=res[1]: reply = "Error: Wrong password!"

    else: reply = ";".join(res)

    return reply_to_remote(reply)

# ************************************************** ACCOUNTS *************************************************
@app.route("/register", methods=["POST"])
def register():
    """ Return Codes:
    0: Registration successfull
    1: username in system
    """
    
    uname = request.form["uname"]
    pswd = request.form["pswd"]
    account_type = request.form["account_type"]
    
    with sql.connect(os.path.join(path, "db", "users.db")) as conn:
        cur = conn.cursor()

        cur.execute("insert into users (uname, pswd, account_type) values (?,?,?)", (uname, pswd, account_type))
        conn.commit()

    print "User <{}> added".format(uname)

    reply = "0"
    return reply_to_remote(reply)

@app.route("/delete_account", methods=["POST"])
def delete_account():
    uname = request.form["uname"]

    with sql.connect(os.path.join(path, "db", "users.db")) as conn:
        cur = conn.cursor()

        cur.execute("delete from users where uname=? and account_type!=?", (uname, "Admin"))
        conn.commit()

    print "User <{}> deleted".format(request.form["uname"])  
    
    reply = "0"
    return reply_to_remote(reply)

@app.route("/edit_account", methods=["POST"])
def edit_account():
    old_uname = request.form["old_uname"]
    new_uname = request.form["new_uname"]
    pswd = request.form["pswd"]
    account_type = request.form["account_type"]

    with sql.connect(os.path.join(path, "db", "users.db")) as conn:
        cur = conn.cursor()

        cur.execute("update users set uname=?, pswd=?, account_type=? where uname=?", (new_uname, pswd, account_type, old_uname))
        conn.commit()

    print "User <{}> edited".format(request.form["old_uname"])
    
    reply = "0"
    return reply_to_remote(reply)
    
# *************************************************** ACCOUNTS ********************************************

# ************************************************** ITEMS **************************************************
@app.route("/promotional_items")
def get_items():

    t = time.localtime()
    t = "{}{}{}".format("0"*(2-len(str(t[0])))+str(t[0]), "0"*(2-len(str(t[1])))+str(t[1]), "0"*(2-len(str(t[2])))+str(t[2]))
    
    with sql.connect(os.path.join(path, "db", "promotional_items.db")) as conn:
        cur = conn.cursor()

        cur.execute("""select * from data where promotion_from<=? and promotion_to>=?""", (t,t))

        items = cur.fetchall()

    reply = json.JSONEncoder().encode(items)
    return reply_to_remote(reply)

@app.route("/promotional_items_all")
def get_items_all():

    with sql.connect(os.path.join(path, "db", "promotional_items.db")) as conn:
        cur = conn.cursor()

        cur.execute("""select * from data""")

        items = cur.fetchall()

    reply = json.JSONEncoder().encode(items)

    return reply_to_remote(reply)

@app.route("/delete_promotional_item", methods=["POST"])
def delete_promotional_item():
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "promotional_items.db")) as conn:
        cur = conn.cursor()
        cur.execute("""delete from data where name=?""", (name,))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/edit_promotional_item", methods=["POST"])
def edit_promotional_item():
    old_name = request.form["old_name"]
    name = request.form["name"]
    _from = request.form["from"]
    _to = request.form["to"]
    unit_price = request.form["unit_price"]

    with sql.connect(os.path.join(path, "db", "promotional_items.db")) as conn:
        cur = conn.cursor()

        cur.execute("""update data set name=?, promotion_from=?, promotion_to=?, unit_price=? where name=?""", (
            name, _from, _to, unit_price, old_name))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/add_promotional_item", methods=["POST"])
def add_promotional_item():
    name = request.form["name"]
    _from = request.form["from"]
    _to = request.form["to"]
    unit_price = request.form["unit_price"]

    with sql.connect(os.path.join(path, "db", "promotional_items.db")) as conn:
        cur = conn.cursor()

        cur.execute("""insert into data values(?,?,?,?)""", (name, _from, _to, unit_price))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/client_segments")
def get_client_segments():
    with sql.connect(os.path.join(path, "db", "client_categories.db")) as conn:
        cur = conn.cursor()

        cur.execute("""select * from categories""")

        items = cur.fetchall()

    reply = json.JSONEncoder().encode(items)
    return reply_to_remote(reply)

@app.route("/add_client_segments", methods=["POST"])
def add_client_segments():
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "client_categories.db")) as conn:
        cur = conn.cursor()

        cur.execute("""insert into categories values(?)""", (name,))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/edit_client_segments", methods=["POST"])
def edit_client_segments():
    old_name = request.form["old_name"]
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "client_categories.db")) as conn:
        cur = conn.cursor()

        cur.execute("""update categories set name=? where name=?""", (name, old_name))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/delete_client_segments", methods=["POST"])
def delete_client_segments():
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "client_categories.db")) as conn:
        cur = conn.cursor()
        cur.execute("""delete from categories where name=?""", (name,))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/mail_recepients")
def get_recepients():
    with sql.connect(os.path.join(path, "db", "mail_recepients.db")) as conn:
        cur = conn.cursor()

        cur.execute("""select * from recepients""")

        items = cur.fetchall()

    reply = json.JSONEncoder().encode(items)
    return reply_to_remote(reply)

@app.route("/add_mail_recepients", methods=["POST"])
def add_mail_recepients():
    email = request.form["email"]

    with sql.connect(os.path.join(path, "db", "mail_recepients.db")) as conn:
        cur = conn.cursor()

        cur.execute("""insert into recepients values(?)""", (email,))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/edit_mail_recepients", methods=["POST"])
def edit_mail_recepients():
    old_email = request.form["old_email"]
    email = request.form["email"]

    with sql.connect(os.path.join(path, "db", "mail_recepients.db")) as conn:
        cur = conn.cursor()

        cur.execute("""update recepients set email=? where email=?""", (email, old_email))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/delete_mail_recepients", methods=["POST"])
def delete_mail_recepients():
    email = request.form["email"]

    with sql.connect(os.path.join(path, "db", "mail_recepients.db")) as conn:
        cur = conn.cursor()
        cur.execute("""delete from recepients where email=?""", (email,))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)


@app.route("/training_topics")
def get_training_topics():
    with sql.connect(os.path.join(path, "db", "training_topics.db")) as conn:
        cur = conn.cursor()

        cur.execute("select name from topics")
    
        res = cur.fetchall()
        topics = [u[0] for u in res]

    reply = json.JSONEncoder().encode(sorted(topics))
    return reply_to_remote(reply)

@app.route("/training_topics_full")
def get_training_topics_full():
    with sql.connect(os.path.join(path, "db", "training_topics.db")) as conn:
        cur = conn.cursor()

        cur.execute("select name from topics")
    
        res = cur.fetchall()

    reply = json.JSONEncoder().encode(sorted(res))
    return reply_to_remote(reply)

@app.route("/add_training_topics", methods=["POST"])
def add_training_topics():
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "training_topics.db")) as conn:
        cur = conn.cursor()

        cur.execute("""insert into topics values(?)""", (name,))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/edit_training_topics", methods=["POST"])
def edit_training_topics():
    old_name = request.form["old_name"]
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "training_topics.db")) as conn:
        cur = conn.cursor()

        cur.execute("""update topics set name=? where name=?""", (name, old_name))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/delete_training_topics", methods=["POST"])
def delete_training_topics():
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "training_topics.db")) as conn:
        cur = conn.cursor()
        cur.execute("""delete from topics where name=?""", (name,))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/activities")
def get_activities():
    with sql.connect(os.path.join(path, "db", "activities.db")) as conn:
        cur = conn.cursor()

        cur.execute("""select * from activities""")

        items = cur.fetchall()

    reply = json.JSONEncoder().encode(items)
    return reply_to_remote(reply)

@app.route("/add_activities", methods=["POST"])
def add_activities():
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "activities.db")) as conn:
        cur = conn.cursor()

        cur.execute("""insert into activities values(?)""", (name,))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/edit_activities", methods=["POST"])
def edit_activities():
    old_name = request.form["old_name"]
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "activities.db")) as conn:
        cur = conn.cursor()

        cur.execute("""update activities set name=? where name=?""", (name, old_name))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/delete_activities", methods=["POST"])
def delete_activities():
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "activities.db")) as conn:
        cur = conn.cursor()
        cur.execute("""delete from activities where name=?""", (name,))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/statuses")
def get_statuses():
    with sql.connect(os.path.join(path, "db", "statuses.db")) as conn:
        cur = conn.cursor()

        cur.execute("""select * from statuses""")

        items = cur.fetchall()

    reply = json.JSONEncoder().encode(items)
    return reply_to_remote(reply)

@app.route("/add_statuses", methods=["POST"])
def add_statuses():
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "statuses.db")) as conn:
        cur = conn.cursor()

        cur.execute("""insert into statuses values(?)""", (name,))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/edit_statuses", methods=["POST"])
def edit_statuses():
    old_name = request.form["old_name"]
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "statuses.db")) as conn:
        cur = conn.cursor()

        cur.execute("""update statuses set name=? where name=?""", (name, old_name))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/delete_statuses", methods=["POST"])
def delete_statuses():
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "statuses.db")) as conn:
        cur = conn.cursor()
        cur.execute("""delete from statuses where name=?""", (name,))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/support_areas")
def get_support_areas():
    with sql.connect(os.path.join(path, "db", "support_areas.db")) as conn:
        cur = conn.cursor()

        cur.execute("""select * from support_areas""")

        items = cur.fetchall()

    reply = json.JSONEncoder().encode(items)
    return reply_to_remote(reply)

@app.route("/add_support_areas", methods=["POST"])
def add_support_areas():
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "support_areas.db")) as conn:
        cur = conn.cursor()

        cur.execute("""insert into support_areas values(?)""", (name,))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/edit_support_areas", methods=["POST"])
def edit_support_areas():
    old_name = request.form["old_name"]
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "support_areas.db")) as conn:
        cur = conn.cursor()

        cur.execute("""update support_areas set name=? where name=?""", (name, old_name))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)

@app.route("/delete_support_areas", methods=["POST"])
def delete_support_areas():
    name = request.form["name"]

    with sql.connect(os.path.join(path, "db", "support_areas.db")) as conn:
        cur = conn.cursor()
        cur.execute("""delete from support_areas where name=?""", (name,))
        conn.commit()

    reply = "0"
    return reply_to_remote(reply)


# ************************************************ REPORT SUBMISSIONS ***********************************
@app.route("/edit_report", methods=["POST"])
def edit_report():
    """
    salesrep
    """
    agent = request.form["uname"]
    t = request.form["time"]
    client = request.form["client"]
    cc = request.form["client_category"]
    co = request.form["client_old"]
    cp = request.form["contact_people"]
    og = request.form["order_generated"]
    orc = request.form["order_received"]
    dc = request.form["debt_collected"]
    pp = request.form["products_promoted"]
    r = request.form["remark"]

    data = (client,cc,co,cp,og,orc,dc,pp,r)

    with sql.connect(os.path.join(path, "db", "sales_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("""
            update data set client=?, 
            client_category=?,
            client_old=?,
            contact_people=?,
            order_generated=?,
            order_received=?,
            debt_collected=?,
            products_promoted=?,
            remark=?
                where uname=? and time=?""", 
           data+(agent, t))
        conn.commit()

    print "edited {}'s daily report".format(agent)

    reply = "0"
    return reply_to_remote(reply)

@app.route("/report", methods=["POST"])
def report():
    """
    salesrep
    """
    uname = request.form["uname"]
    _date = request.form["date"]
    t = request.form["time"]
    client = request.form["client"]
    lat = request.form["lat"]
    lon = request.form["lon"]
    cc = request.form["client_category"]
    co = request.form["client_old"]
    cp = request.form["contact_people"]
    og = request.form["order_generated"]
    orc = request.form["order_received"]
    dc = request.form["debt_collected"]
    pp = request.form["products_promoted"]
    r = request.form["remark"]

    data = (uname,_date,t,client,lat,lon,cc,co,cp,og,orc,dc,pp,r)

    with sql.connect(os.path.join(path, "db", "sales_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("insert into data values({})".format(("?,"*len(data))[:-1]), data)
        conn.commit()

    print "added {}'s daily report".format(uname)

    reply = "0"
    return reply_to_remote(reply)

@app.route("/technical_report", methods=["POST"])
def technical_report():
    uname = request.form["uname"]
    _date = request.form["date"]
    t = request.form["time"]
    facility = request.form["facility"]
    lat = request.form["lat"]
    lon = request.form["lon"]
    remark = request.form["remark"]
    CMEs = request.form["CMEs"]
    area_trained = request.form["area_trained"]

    data = (uname,CMEs,facility,_date,t,lat,lon,area_trained,remark)

    with sql.connect(os.path.join(path, "db", "technical_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("insert into data values({})".format(("?,"*len(data))[:-1]), data)
        conn.commit()

    print "added {}'s technical report".format(uname)

    reply = "0"
    return reply_to_remote(reply)

@app.route("/technical_report_tp", methods=["POST"])
def technical_report_tp():
    uname = request.form["uname"]
    _date = request.form["date"]
    t = request.form["time"]
    facility = request.form["facility"]
    lat = request.form["lat"]
    lon = request.form["lon"]
    remark = request.form["remark"]
    #supervision_visits = request.form["supervision_visits"]
    support_areas = request.form["support_areas"]
    incharge = request.form["incharge"]
    trainees = request.form["trainees"]

    data = (uname,facility,_date,t,lat,lon,support_areas,incharge,trainees,remark)

    with sql.connect(os.path.join(path, "db", "technical_reps_tp_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("insert into data values({})".format(("?,"*len(data))[:-1]), data)
        conn.commit()

    print "added {}'s technical report".format(uname)

    reply = "0"
    return reply_to_remote(reply)

@app.route("/technical_report_core", methods=["POST"])
def technical_report_core():
    uname = request.form["uname"]
    _date = request.form["date"]
    t = request.form["time"]
    facility = request.form["facility"]
    lat = request.form["lat"]
    lon = request.form["lon"]
    remark = request.form["remark"]
    activities = request.form["activities"]
    issues_arising = request.form["issues_arising"]
    personnels_engaged = request.form["personnels_engaged"]
    time_spent = request.form["time_spent"]
    status_of_engagement = request.form["status_of_engagement"]
    perfomance_against_target = request.form["perfomance_against_target"]

    data = (uname,facility,_date,t,lat,lon,activities,personnels_engaged,issues_arising,time_spent,status_of_engagement,perfomance_against_target,remark)

    with sql.connect(os.path.join(path, "db", "technical_reps_core_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("insert into data values({})".format(("?,"*len(data))[:-1]), data)
        conn.commit()

    print "added {}'s technical report".format(uname)

    reply = "0"
    return reply_to_remote(reply)

# ************************************************ REPORT SUBMISSIONS ***********************************


# *************************************************** REPORT FETCHING ***************************************************
@app.route("/agent_specific_report", methods=["POST"])
def get_agent_specific_report():
    agent = request.form["agent"]
    t = request.form["time"]

    with sql.connect(os.path.join(path, "db", "sales_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("""select * from data where uname=? and time=?""", (agent, t))
        rep = cur.fetchone()

    reply = json.JSONEncoder().encode(rep)
    return reply_to_remote(reply)

@app.route("/agent_reports", methods=["POST"])
def get_agent_reports():
    agent = request.form["agent"]
    date = request.form["date"]

    with sql.connect(os.path.join(path, "db", "sales_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("""select time, client from data where uname=? and date=?""", (agent, date))
        rep = cur.fetchall()

    reply = json.JSONEncoder().encode(rep)
    return reply_to_remote(reply)

@app.route("/clients_visited_report", methods=["POST"])
def clients_visited_report():
    _from = request.form["from"]
    _to = request.form["to"]
    target = request.form["target"]

    data = []
    
    # sales reps
    with sql.connect(os.path.join(path, "db", "sales_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("select date,time,uname,client from data where client like \"%{}%\" and date>=? and date<=?".format(target),
                (_from, _to))
        rep = cur.fetchall()

        if rep: data += list(rep)

    # technical reps
    with sql.connect(os.path.join(path, "db", "technical_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("select date,time,uname,facility from data where facility like \"%{}%\" and date>=? and date<=?".format(target),
                (_from, _to))
        rep = cur.fetchall()

        if rep: data += list(rep)

    # technical reps
    with sql.connect(os.path.join(path, "db", "technical_reps_tp_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("select date,time,uname,facility from data where facility like \"%{}%\" and date>=? and date<=?".format(target),
                (_from, _to))
        rep = cur.fetchall()

        if rep: data += list(rep)

    # technical reps
    with sql.connect(os.path.join(path, "db", "technical_reps_core_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("select date,time,uname,facility from data where facility like \"%{}%\" and date>=? and date<=?".format(target),
                (_from, _to))
        rep = cur.fetchall()

        if rep: data += list(rep)


    reply = json.JSONEncoder().encode(data)
    return reply_to_remote(reply)

@app.route("/clients_segments_report", methods=["POST"])
def clients_segments_report():
    _from = request.form["from"]
    _to = request.form["to"]
    target = request.form["target"]

    with sql.connect(os.path.join(path, "db", "sales_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("""
            select date,time,uname,client,client_category from data where 
            client_category like \"%{}%\" and date>=? and date<=?""".format(target), (_from, _to))
        rep = cur.fetchall()

    reply = json.JSONEncoder().encode(rep)
    return reply_to_remote(reply)

@app.route("/debts_collected_report", methods=["POST"])
def debts_collected_report():
    _from = request.form["from"]
    _to = request.form["to"]

    with sql.connect(os.path.join(path, "db", "sales_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("select date,time,uname,client,debt_collected from data where date>=? and date<=?", (_from, _to))
        rep = cur.fetchall()

    reply = json.JSONEncoder().encode(rep)
    return reply_to_remote(reply)

@app.route("/orders_report", methods=["POST"])
def orders_report():
    _from = request.form["from"]
    _to = request.form["to"]

    with sql.connect(os.path.join(path, "db", "sales_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("select date,time,uname,client,order_generated, order_received from data where date>=? and date<=?", (_from, _to))
        rep = cur.fetchall()

    reply = json.JSONEncoder().encode(rep)
    return reply_to_remote(reply)

@app.route("/agents_report", methods=["POST"])
def agents_report():
    _from = request.form["from"]
    _to = request.form["to"]
    target = request.form["target"]

    data = []
    
    with sql.connect(os.path.join(path, "db", "sales_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("select date,time,uname from data where uname like \"%{}%\" and date>=? and date<=?".format(target),
                (_from, _to))
        rep = cur.fetchall()

        if rep: data += list(rep)

    # technical reps
    with sql.connect(os.path.join(path, "db", "technical_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("select date,time,uname from data where uname like \"%{}%\" and date>=? and date<=?".format(target),
                (_from, _to))
        rep = cur.fetchall()

        if rep: data += list(rep)


    reply = json.JSONEncoder().encode(data)
    return reply_to_remote(reply)

@app.route("/agents_report_all_data", methods=["POST"])
def agents_report_all_data():
    _from = request.form["from"]
    _to = request.form["to"]
    target = request.form["target"]
    account_type = request.form["account_type"]

    data = []

    # sales reps
    if account_type=="salesrep":
        with sql.connect(os.path.join(path, "db", "sales_reps_data.db")) as conn:
            cur = conn.cursor()

            cur.execute("select date,time,uname,client,client_category,client_old,order_generated,order_received,debt_collected from data where uname like \"%{}%\" and date>=? and date<=?".format(target),
                    (_from, _to))
            rep = cur.fetchall()

            if rep: data += list(rep)

    # technical reps
    elif account_type=="technicalrep":
        with sql.connect(os.path.join(path, "db", "technical_reps_data.db")) as conn:
            cur = conn.cursor()

            cur.execute("select date,time,uname,facility,CMEs,area_trained from data where uname like \"%{}%\" and date>=? and date<=?".format(target),
                    (_from, _to))
            rep = cur.fetchall()

            if rep: data += list(rep)

    # technical reps-tp
    elif account_type=="technicalrep_tp":
        with sql.connect(os.path.join(path, "db", "technical_reps_tp_data.db")) as conn:
            cur = conn.cursor()

            cur.execute("select date,time,uname,facility,incharge,support_areas from data where uname like \"%{}%\" and date>=? and date<=?".format(target),
                    (_from, _to))
            rep = cur.fetchall()

            if rep: data += list(rep)

    # technical reps-core
    elif account_type=="technicalrep_core":
        with sql.connect(os.path.join(path, "db", "technical_reps_core_data.db")) as conn:
            cur = conn.cursor()

            cur.execute("select date,time,uname,facility,time_spent,status_of_engagement,activities from data where uname like \"%{}%\" and date>=? and date<=?".format(target),
                    (_from, _to))
            rep = cur.fetchall()

            if rep: data += list(rep)


    reply = json.JSONEncoder().encode(data)
    return reply_to_remote(reply)


@app.route("/new_clients_report", methods=["POST"])
def new_clients_report():
    _from = request.form["from"]
    _to = request.form["to"]
    target = request.form["target"]

    with sql.connect(os.path.join(path, "db", "sales_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("select date,time,uname,client from data where client_old=? and date>=? and date<=? and client like \"%{}%\"".format(target),
                ("no", _from, _to))
        rep = cur.fetchall()

    reply = json.JSONEncoder().encode(rep)
    return reply_to_remote(reply)

@app.route("/products_promoted_report", methods=["POST"])
def products_promoted_report():
    _from = request.form["from"]
    _to = request.form["to"]
    target = request.form["target"]

    # sales reps
    with sql.connect(os.path.join(path, "db", "sales_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("""select date,time,uname,products_promoted from data where 
               products_promoted like \"%{}%\" and products_promoted>? and date>=? and date<=?""".format(target),
                ("", _from, _to))
        rep = cur.fetchall()

    reply = json.JSONEncoder().encode(rep)
    return reply_to_remote(reply)

@app.route("/topics_taughed_report", methods=["POST"])
def topics_taughed_report():
    _from = request.form["from"]
    _to = request.form["to"]
    target = request.form["target"]

    # sales reps
    with sql.connect(os.path.join(path, "db", "technical_reps_data.db")) as conn:
        cur = conn.cursor()

        cur.execute("""select date,time,uname,facility,area_trained from data where 
               area_trained like \"%{}%\" and date>=? and date<=?""".format(target),
                (_from, _to))
        rep = cur.fetchall()

    reply = json.JSONEncoder().encode(rep)
    return reply_to_remote(reply)

@app.route("/full_report", methods=["POST"])
def full_report():
    _date = request.form["date"]
    _time = request.form["time"]
    target = request.form["target"]

    # first determine if user is a sales rep or technical rep
    with sql.connect(os.path.join(path, "db", "users.db")) as conn:
        cur = conn.cursor()

        cur.execute("select account_type from users where uname=?", (target,))

        account_type = cur.fetchone()[0]

    if account_type=="SalesRep":
        # sales reps
        with sql.connect(os.path.join(path, "db", "sales_reps_data.db")) as conn:
            cur = conn.cursor()

            cur.execute("select * from data where uname like \"%{}%\" and date=? and time=?".format(target),
                    (_date, _time))
            rep = cur.fetchone()

    elif account_type=="TechnicalRep":
        # technical reps
        with sql.connect(os.path.join(path, "db", "technical_reps_data.db")) as conn:
            cur = conn.cursor()

            cur.execute("select * from data where uname like \"%{}%\" and date=? and time=?".format(target),
                    (_date, _time))
            rep = cur.fetchone()

    elif account_type=="TechnicalRep-TP":
        # technical reps
        with sql.connect(os.path.join(path, "db", "technical_reps_tp_data.db")) as conn:
            cur = conn.cursor()

            cur.execute("select * from data where uname like \"%{}%\" and date=? and time=?".format(target),
                    (_date, _time))
            rep = cur.fetchone()

    elif account_type=="TechnicalRep-Core":
        # technical reps
        with sql.connect(os.path.join(path, "db", "technical_reps_core_data.db")) as conn:
            cur = conn.cursor()

            cur.execute("select * from data where uname like \"%{}%\" and date=? and time=?".format(target),
                    (_date, _time))
            rep = cur.fetchone()


    reply = json.JSONEncoder().encode(rep)
    return reply_to_remote(reply)
# *************************************************** REPORT FETCHING ***************************************************

# maps service
@app.route("/map/<lat>/<lon>")
def get_map(lat, lon):
    map_template = GOOGLE_MAPS_TEMPLATE
    map_template = "".join([map_template[0], map_template[1]%(lat,lon), map_template[2]])
    reply = map_template
    return reply_to_remote(reply)

# *************************************************** SENDING CLIENT(admin) CUSTOM EMAILS *******************************
@app.route("/send_mail", methods=["POST"])
def send_mail():
    data = request.form["data"]
    data = json.JSONDecoder().decode(data)
    
    send_client_email.send_client_email(*data)
    
    reply = "0"
    return reply_to_remote(reply)
# ***********************************************************************************************************************

if __name__=="__main__":
    app.run(*addr, debug=1, threaded=1)
